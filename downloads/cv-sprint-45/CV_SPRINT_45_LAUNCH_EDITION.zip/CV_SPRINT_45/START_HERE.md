# CV SPRINT 45

## Jedna pozice. Jeden soustředěný blok. Hotová přihláška a příprava na pohovor.

Tento kit změní pracovní inzerát, vaše reálné zkušenosti a existující CV na:

- mapu toho, co firma skutečně hledá,
- 4 až 6 cílených CV bodů,
- krátký motivační text,
- 90sekundové představení,
- banku STAR příběhů,
- pravděpodobné otázky a chytré dotazy na firmu.

Funguje s ChatGPT, Claude, Gemini nebo jiným kvalitním jazykovým modelem. Není s těmito firmami spojen ani jimi podporován.

## Pravidlo nula: žádné vymyšlené úspěchy

AI nesmí doplnit zaměstnavatele, datum, certifikaci, výsledek, metriku, plat ani technologii, kterou jste neuvedli. Když chybí důkaz, musí položit krátkou otázku nebo použít označení `[DOPLNIT]`.

## 45minutový sprint

### 00–05 | Vstupy

Připravte celý text inzerátu, aktuální CV a tři příklady práce, na které jste hrdí. Nemusí být dokonale napsané.

### 05–12 | Signál z inzerátu

Použijte příkaz 01. Vytáhněte pět hlavních požadavků, důkazy, které je mohou pokrýt, a chybějící informace.

### 12–25 | CV důkazy

Použijte příkazy 02 a 03. Vyberte jen pravdivé body, které odpovídají konkrétní pozici. Metriky doplňte pouze tehdy, když je dokážete obhájit.

### 25–32 | Motivace

Použijte příkaz 04. Výsledek zkraťte tak, aby zněl jako vy, ne jako reklamní text.

### 32–40 | Pohovor

Použijte příkazy 05 až 08. Nahlas si jednou řekněte 90sekundové představení a dva STAR příběhy.

### 40–45 | Kontrola a odeslání

Použijte příkaz 12. Zkontrolujte jména, data, čísla, odkazy a jazyk. AI výstup je návrh; odpovědnost za finální text máte vy.

## Co otevřít

- `CV_SPRINT_45_PLAYBOOK.pdf` — hlavní mobilní a tisknutelný handbook.
- `COPY_PASTE_AI_COMMANDS.md` — všechny příkazy bez omáčky.
- `STAR_STORY_WORKSHEET.pdf` — jednostránkový pracovní list.
- `WORKED_EXAMPLES.md` — tři fiktivní ukázky vstup → výstup.
- `LICENSE.txt` — licence a omezení.

## Minimální definice „hotovo“

Sprint je hotový, když máte jeden cílený dokument odeslatelný pro konkrétní pozici a umíte bez čtení říct: kdo jste, proč tato role a jeden důkaz, že ji zvládnete.
