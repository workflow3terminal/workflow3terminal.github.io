# TŘI FIKTIVNÍ UKÁZKY

Ukázky níže demonstrují metodu. Jména, firmy a situace jsou smyšlené. Nejsou to tvrzení o skutečných klientech ani garance výsledku.

## 1 — Ze syrové praxe na CV bod

### Vstup

`Pomáhal jsem instalovat trouby v hotelu, řešil jsem nářadí, přenášení a domluvu na místě.`

### Slabý výstup

`Expertně jsem řídil komplexní hotelový projekt a zvýšil efektivitu o 40 %.`

Problém: tvrdí vedení projektu a metriku, které ve vstupu nejsou.

### Bezpečný výstup

- Podílel se na instalaci hotelových trub a koordinoval přípravu nářadí a materiálu na místě.
- Řešil operativní přesuny vybavení a navazující úkoly podle aktuálního stavu zakázky.
- Spolupracoval s týmem na dokončení montážních prací v provozním prostředí hotelu.

Co doplnit: počet jednotek, moje přesná role, termín a doložitelný výsledek.

## 2 — Z inzerátu na 90sekundové představení

### Vstupy

- Role: junior project coordinator.
- Důkazy: koordinace montážního dne, komunikace mezi lidmi na místě, evidence úkolů.
- Cíl: přechod z terénu k organizaci projektu.

### Výstup

`Poslední roky jsem pracoval v rolích, kde se potkává zákazník, technický problém a reálný termín. V terénu jsem si ověřil, že moje nejsilnější stránka není jen samotné provedení úkolu, ale hlavně orientace v tom, co musí následovat, kdo co potřebuje a kde vzniká blokace. Při posledních zakázkách jsem pomáhal koordinovat přípravu nářadí, přesuny a komunikaci na místě. Teď hledám roli juniorního project coordinatora, kde tuto praktickou zkušenost převedu do systematického plánování a budu se dál učit pod vedením zkušenějšího týmu.`

Proč funguje: propojuje minulost, důkaz a další krok bez předstírání seniority.

## 3 — STAR bez nafukování výsledku

### Syrová vzpomínka

`Na místě chybělo správné nářadí. Museli jsme se vrátit a ztratil se čas. Příště jsem udělal seznam.`

### STAR

- Situace: Před montáží jsme zjistili, že chybí část potřebného nářadí.
- Úkol: Potřeboval jsem pomoci práci znovu rozběhnout a snížit riziko opakování.
- Akce: Ověřil jsem chybějící položky, pomohl zajistit jejich dovoz a pro další výjezd připravil kontrolní seznam.
- Výsledek: Tým měl pro další výjezd jasnou kontrolu přípravy. Časovou úsporu je třeba doplnit jen pokud existuje záznam.
- Poučení: Před odjezdem odděluji povinné nářadí, spotřební materiál a rezervy.
