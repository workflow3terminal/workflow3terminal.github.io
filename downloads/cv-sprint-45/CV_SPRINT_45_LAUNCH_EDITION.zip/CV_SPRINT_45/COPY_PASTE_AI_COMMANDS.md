# COPY-PASTE AI PŘÍKAZY

## Bezpečnostní hlavička — vložte na začátek chatu

```text
Pracuj pouze s fakty, které ti dodám. Nevymýšlej zaměstnavatele, data, vzdělání, certifikace, technologie, výsledky ani metriky. Když chybí kritický fakt, polož maximálně tři krátké otázky. Když lze pokračovat bez něj, označ místo [DOPLNIT]. Výstupní jazyk: [čeština / angličtina]. Cílová pozice: [NÁZEV POZICE].
```

## 01 — Rozkóduj inzerát

```text
Zde je celý inzerát: [VLOŽIT]. Vytvoř tabulku: 1) pět nejdůležitějších požadavků, 2) přesný důkaz nebo fráze z inzerátu, 3) co z mého CV může požadavek pokrýt, 4) co mi chybí a musím doplnit. Odděl povinné požadavky od výhod.
```

## 02 — Důkazová matice CV

```text
Moje CV: [VLOŽIT]. K pěti hlavním požadavkům vytvoř důkazovou matici. U každého označ SILNÝ DŮKAZ / ČÁSTEČNÝ DŮKAZ / BEZ DŮKAZU. Nic nedoplňuj z domněnek. Na konci doporuč tři body, které mají být v první polovině CV.
```

## 03 — Přepis pracovních zkušeností

```text
Syrový popis práce: [VLOŽIT]. Cílová pozice: [POZICE]. Vytvoř šest pravdivých CV bodů ve formátu činnost → kontext → dopad. Když chybí číslo, navrhni v hranaté závorce, co lze změřit, ale žádné číslo nevymýšlej. Maximálně 18 slov na bod.
```

## 04 — Krátká motivace bez klišé

```text
Inzerát: [VLOŽIT]. Moje tři relevantní důkazy: [VLOŽIT]. Napiš motivační text 120–160 slov. Struktura: proč tato role, dva konkrétní důkazy, co chci doručit v prvních 90 dnech. Bez frází typu dynamický tým, vášnivý profesionál nebo dream job.
```

## 05 — 90sekundové představení

```text
Cílová role: [POZICE]. Moje současná situace: [VLOŽIT]. Dva nejsilnější důkazy: [VLOŽIT]. Napiš mluvenou odpověď na „Řekněte mi něco o sobě“: minulost → současnost → proč tato role. 130–170 slov, krátké věty, žádná vymyšlená fakta.
```

## 06 — Pravděpodobné otázky

```text
Z inzerátu a mého CV vytvoř 10 nejpravděpodobnějších otázek. U každé uveď, co tazatel testuje, který můj reálný důkaz mám použít a dvouvětnou osnovu odpovědi. Označ tři otázky jako KRITICKÉ.
```

## 07 — STAR příběh z reality

```text
Moje syrová vzpomínka: [VLOŽIT]. Převeď ji do STAR: situace, úkol, tři konkrétní kroky, výsledek a poučení. Pokud výsledek nebo moje osobní role není jasná, zeptej se. Vytvoř i 45sekundovou mluvenou verzi.
```

## 08 — Šest STAR příběhů

```text
Moje zkušenosti: [VLOŽIT]. Navrhni šest kategorií příběhu: výsledek, problém, konflikt, chyba, iniciativa, učení. Pro každou vyber pouze doložitelnou událost. Kde chybí materiál, napiš CHYBÍ PŘÍBĚH a polož jednu otázku.
```

## 09 — Slabina nebo chyba bez červené vlajky

```text
Moje skutečná slabina nebo chyba: [VLOŽIT]. Role: [POZICE]. Pomoz mi vytvořit 45sekundovou odpověď: přiznat, ukázat konkrétní nápravu, doložit nový návyk. Nezmenšuj odpověď falešnou slabinou typu „jsem perfekcionista“.
```

## 10 — Platové očekávání

```text
Role a lokalita: [VLOŽIT]. Můj reálný minimální příjem: [ČÁSTKA]. Moje preferované rozpětí: [ROZPĚTÍ]. Napiš tři odpovědi: když se ptají brzy, po vysvětlení role a při nabídce pod minimem. Neprováděj tržní průzkum bez zdrojů.
```

## 11 — Chytré otázky na firmu

```text
Inzerát: [VLOŽIT]. Vytvoř osm otázek, které odkryjí: úspěch po 90 dnech, reálnou náplň práce, vedení, rozhodování, důvod otevření role, zátěž, růst a rizika. Vynech odpovědi snadno dostupné na webu firmy.
```

## 12 — Anti-hallucination final check

```text
Finální návrh: [VLOŽIT]. Porovnej ho pouze s mým původním CV a poznámkami: [VLOŽIT]. Vrať tři seznamy: OVĚŘENO, CHYBÍ DŮKAZ, OPRAVIT PŘED ODESLÁNÍM. Kontroluj jména, data, čísla, technologie, pravopis, odkazy a tvrzení o výsledcích. Nic potichu neopravuj.
```

## Nouzový master příkaz — pohovor do dvou hodin

```text
Mám pohovor za [ČAS]. Inzerát: [VLOŽIT]. CV: [VLOŽIT]. Vytvoř přípravu v tomto pořadí: 1) pět signálů z inzerátu, 2) 90sekundové představení, 3) deset otázek s osnovou odpovědi, 4) tři STAR příběhy pouze z mých faktů, 5) odpověď na „proč tato firma“, 6) platové očekávání z mých čísel, 7) pět otázek na firmu, 8) desetiminutový drill nahlas. Žádné vymyšlené údaje; nejasnosti označ [DOPLNIT].
```
