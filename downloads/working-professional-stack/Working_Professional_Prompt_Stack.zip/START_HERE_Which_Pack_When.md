# Start here — which pack when?

Read this once, then open the pack that matches **today’s problem**.

---

## Use **Job Search** when you…

- Are sending applications or need a CV/LinkedIn pass.
- Have an interview coming up (including “last minute”).
- Need cover letters or answers to written application questions.
- Want recruiter messages, thank-you emails, or salary framing.

**Open:** `Job_Search_Prompt_Pack.md`

---

## Use **Business English** when you…

- Write email or Slack at work and worry about tone (too blunt / too weak).
- Need bad news, apologies, escalations, or saying no without burning bridges.
- Want meeting invites, updates, or speaking notes that sound natural.
- Speak English as a second language and want **clear** professional phrasing.

**Open:** `Business_English_Prompt_Pack.md`

---

## Use **Freelance Client Control** when you…

- Need proposals, SOWs, or scope boundaries in writing.
- Face scope creep, vague feedback, rush requests, or “quick favors.”
- Must chase invoices, raise rates, pause a project, or end a client cleanly.
- Want discovery questions and change-order language that protects your time.

**Open:** `Freelance_Client_Control_Prompt_Pack.md`

---

## Fast workflow

1. Copy **one** prompt from the pack.
2. Paste into your AI. Fill the `[brackets]` with your real details.
3. Send the **output** only after you agree with it — you’re the final editor.

---

## Session primer (optional — paste at the start of a chat)

**Job search:**  
`You are my career coach and editor. My goal: [role type + industry]. Constraints: [location/remote, visa, salary band]. Tone: [direct / warm / formal]. Give: (1) text ready to paste, (2) up to 2 alternatives, (3) one line why this works. Ask only if a fact is missing.`

**Business English:**  
`You are my professional English editor. Preserve my meaning. Style: [diplomatic / direct / warm]. Context: [peer / boss / client]. Output: (1) final text to send, (2) optional softer version, (3) 3 subject lines if email.`

**Freelance:**  
`You are my freelance business coach. Service: []. Rate: []. Policy: [revisions/hours]. Tone: [firm but fair / warm]. Output must be send-ready. Give: (1) message to send, (2) optional firmer version.`
