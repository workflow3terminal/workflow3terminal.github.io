# Business English Prompt Pack

**Email · Slack · Meetings · Professional tone**

*Personal use only — see license at end.*

---

## How to use this pack

Copy one prompt at a time into your AI. Replace everything in `[brackets]` with your real situation.

**Optional session primer (paste once per chat):**

```
You are my professional English editor. Preserve my meaning and level of directness. Target style: [diplomatic / direct / warm]. Context: [peer / boss / client]. Output: (1) final text to send, (2) optional softer version, (3) 3 subject lines if this is an email.
```

---

## Prompts

### 1 — Email: clarify without sounding rude

```
Draft idea: [paste]. Recipient: [role]. Make it clear and polite.
```

### 2 — Email: bad news

```
Situation: []. Recipient: []. Write a bad-news email: brief, solution-oriented, no over-apology.
```

### 3 — Email: chase a deadline

```
Waiting on [deliverable] from [who]. Today is [date]. Write a firm but polite chase.
```

### 4 — Slack: async ask

```
I need [X] by [when]. Write a Slack message: friendly, scannable, with a bullet ask.
```

### 5 — Slack: push back on urgency

```
They want it today; realistic delivery is []. Write pushback plus an alternative timeline.
```

### 6 — Meeting request

```
Goal of meeting: []. Attendees: []. Write invite text, 3 time options, and short agenda lines.
```

### 7 — Decline meeting / delegate

```
I can’t attend because []. Suggest [name] instead. Write a short decline.
```

### 8 — Apology (professional)

```
I messed up: []. Impact: []. Write an apology that includes fix and one prevention line.
```

### 9 — Disagree with manager

```
I disagree because [evidence]. Write respectful disagreement plus a clear ask for a decision.
```

### 10 — Escalate (carefully)

```
Issue: []. Already tried: []. Write an escalation email to skip-level or PMO without sounding emotional.
```

### 11 — Say no to extra work

```
Request: []. Reason: [capacity or priority]. Write a no plus one constructive alternative.
```

### 12 — Intro / networking email

```
I want to connect with [who] about [topic]. Mutual context: []. Write a concise intro request.
```

### 13 — Customer-facing: delay

```
Project delayed until [date]. Reason (sanitized): []. Write the client email.
```

### 14 — Customer-facing: scope change

```
They asked for [extra]. Contract or agreement covers []. Write a scope note with options A/B and pricing if applicable.
```

### 15 — Speaking notes from bullets

```
Topic: []. Bullets: []. Turn into spoken notes for a 3-minute update: simple words, short sentences.
```

### 16 — Slide titles + takeaway lines

```
Content: [paste]. Give 8 slide titles and one-line takeaway for each.
```

### 17 — Correct my English (keep my voice)

```
My draft: [paste]. Fix grammar and awkward phrasing but keep my tone and intent.
```

### 18 — UK vs US tone

```
Rewrite this for UK business tone: [paste]. Then US tone. Note the main differences briefly.
```

### 19 — Sounds too “AI” — humanize

```
This text: [paste]. Make it sound like a busy professional wrote it: natural rhythm, no marketing clichés.
```

### 20 — Sensitive / cross-cultural phrasing

```
I need to say [intent] across cultures. Give neutral international English plus one softer variant.
```

---

## Emergency — reply in 10 minutes

```
Incoming message: [paste]. My goal: []. Write a reply under 120 words plus one backup softer version.
```

---

## Power tips (5)

1. Always state **relationship** (peer vs boss vs client) — it changes tone.  
2. Paste **their last message** when replying so your answer fits the thread.  
3. Ask for **simple connectors** (However / Therefore / Could we) instead of heavy idioms if you want clarity.  
4. Prefer **one clear ask** per message when possible.  
5. Save **your** sign-offs and ask the AI to reuse them.

---

## Remix (add to any prompt)

- `More direct (US tech startup).`  
- `More indirect (consensus culture).`  
- `Shorter; mobile-first.`  
- `I am non-native; prioritize clarity over flair.`

---

## License

**Personal use only.** Do not resell or redistribute this pack. You are responsible for final content and appropriateness in your workplace.
