# The Working Professional Prompt Stack

**Three prompt packs in one download.** Job search, business English, and freelance client control — copy-paste ready for ChatGPT / Claude / similar.

## What you get

| File | For you if… |
|------|----------------|
| `START_HERE_Which_Pack_When.md` | You’re not sure where to start — read this first (2 minutes). |
| `Job_Search_Prompt_Pack.md` | You’re applying, interviewing, or refreshing LinkedIn/CV. |
| `Business_English_Prompt_Pack.md` | You write email/Slack at work and want clear, professional English. |
| `Freelance_Client_Control_Prompt_Pack.md` | You’re freelancing and need scope, boundaries, and money conversations in writing. |

## How to sell this (you)

1. Open each `.md` in **Preview** (Mac) or **Google Docs** / **Word** → **Export as PDF** if your store requires PDF.
2. Zip this folder (or the PDFs) → upload to Gumroad (or Payhip / Lemon Squeezy).
3. **Suggested honest pricing:** **$22** per pack if sold separately · **$49** for this full bundle (saves vs buying three singles).

## Honest notes

- AI output is **your** responsibility — check facts, names, numbers, and legal edge cases.
- These packs are **personal use**; resale of the pack itself is not allowed (see license in each file).

## Version

Pipeline run #1 · Built for digital download.

## Listings & social (generated copy)

`../content_engine/` — edit `context/products/working_professional_stack.json`, run `python3 scripts/render.py --product working_professional_stack`, then open `dist/` and `playbooks/<platform>/` for steps (Etsy, Gumroad, X, Instagram, Pinterest, Facebook, Lemon Squeezy, Payhip).
