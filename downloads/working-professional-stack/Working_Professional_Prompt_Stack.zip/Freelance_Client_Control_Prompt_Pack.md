# Freelance Client Control Prompt Pack

**Scope · boundaries · proposals · money · awkward conversations**

*Personal use only — see license at end.*

---

## How to use this pack

Copy one prompt at a time into your AI. Replace everything in `[brackets]` with your real project terms.

**Optional session primer (paste once per chat):**

```
You are my freelance business coach. My service: []. My typical rate: []. My policy: [revisions / included hours]. Tone: [firm but fair / warm]. Output must be send-ready; avoid lecturing the client. Give: (1) message to send, (2) optional firmer version.
```

---

## Prompts

### 1 — Discovery questions

```
Client wants [type of work]. Give 12 discovery questions plus follow-ups to surface scope, deadline, stakeholders, and success criteria.
```

### 2 — Proposal from call notes

```
Call notes: [paste]. Turn into a proposal: summary, scope, deliverables, timeline, revisions, price, assumptions, payment terms.
```

### 3 — Scope of work — one pager

```
Project: []. Deliverables: []. Out of scope: []. Write a SOW-style paragraph plus bullet list a client can mentally sign off on.
```

### 4 — Out of scope email

```
They asked for [extra]. Contract or agreement says []. Write an out-of-scope email with an option to add a change order for $[ ].
```

### 5 — Revision limit reminder

```
We included [N] rounds. This is round []. Write a polite reminder and ask for consolidated feedback.
```

### 6 — Timeline slip — your fault

```
New delivery date: []. Reason (brief, honest): []. Write the client message plus an optional small make-good.
```

### 7 — Timeline slip — their fault

```
Blocked by [missing asset or feedback]. Impact: []. Write a message with a new date tied to their action.
```

### 8 — Raise rates (existing client)

```
Old rate: []. New rate: []. Effective: []. Relationship: []. Write a rate increase email focused on value, not apology.
```

### 9 — Pause project

```
Reason: [payment / no feedback / client chaos]. Write a pause email stating what has to happen before work resumes.
```

### 10 — End relationship cleanly

```
I need to stop because []. Write a professional ending plus brief handoff suggestions.
```

### 11 — Invoice reminder (gentle → firm)

```
Invoice #[ ] due [date]. Write: (a) gentle reminder, (b) firm reminder, (c) final message before pause.
```

### 12 — Late fee / overdue tone

```
Terms say []. Days overdue: []. Write a firm message that preserves the relationship if possible.
```

### 13 — “Quick favor” pushback

```
They asked for [small free task]. Write a boundary reply offering a paid option.
```

### 14 — Vague feedback → specific ask

```
Their feedback: [paste]. Write a reply that turns vague comments into a numbered checklist for approval.
```

### 15 — Rush fee

```
They need it by [sooner date]. Write a message offering rush delivery for +$[ ] or an alternative date at standard terms.
```

### 16 — Deposit request

```
Project total: []. Deposit policy: []. Write a deposit request and state the start date after payment clears.
```

### 17 — Meeting → written approval

```
We agreed: [summary]. Write an email that confirms decisions in bullets and asks for written OK.
```

### 18 — Red flag client (internal notes)

```
Chronology: [bullets]. Write neutral internal notes I could use if there is a dispute later.
```

### 19 — Handoff to subcontractor

```
Task: []. Deadline: []. Write a brief for a subcontractor plus a client-safe status update template.
```

### 20 — Testimonial ask

```
Project: []. Result: []. Write a short testimonial request plus 3 prompts they can answer easily.
```

---

## Emergency — scope explosion tonight

```
Original scope: []. They now want: []. Write tonight’s reply: acknowledge, restate scope, offer a change order with price, and propose one call slot.
```

---

## Power tips (5)

1. Put **dates and triggers** in timeline messages (“delivery X after assets by Y”).  
2. One **SOW or proposal** beats ten chat promises — refer to it in follow-ups.  
3. Change orders: always pair **price** with **deadline**.  
4. Keep a **policy snippet** you reuse (revisions, rush, payment).  
5. If you’re heated, add: *“Remove emotional adjectives; keep facts.”*

---

## Remix (add to any prompt)

- `Friendlier tone (long-term relationship client).`  
- `Minimal warmth; attorney-clean.`  
- `Non-native English; simpler grammar.`  
- `Shorter; they read on mobile.`

---

## License

**Personal use only.** Do not resell or redistribute this pack. This is **not** legal advice. For contracts and disputes, use a qualified professional where needed.
