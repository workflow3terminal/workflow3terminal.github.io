# Job Search Prompt Pack

**CV · LinkedIn · Applications · Interviews**

*Personal use only — see license at end.*

---

## How to use this pack

Copy one prompt at a time into your AI. Replace everything in `[brackets]` with your real information.

**Optional session primer (paste once per chat):**

```
You are my career coach and editor. My goal: [specific role type + industry]. My constraints: [location/remote, visa, salary band]. Tone: [direct / warm / formal]. Always give: (1) revised text ready to paste, (2) 2 alternatives if useful, (3) a 1-line “why this works.” Ask only if a fact is missing; otherwise assume reasonable defaults.
```

---

## Prompts

### 1 — CV: turn a job into metric bullets

```
Here is my rough description of what I did: [paste]. Turn it into 5–8 resume bullets with strong verbs and metrics. If metrics are missing, suggest plausible placeholders as [METRIC] and tell me what to measure.
```

### 2 — CV: one-page tighten

```
Here is my full CV text: [paste]. Cut to one page for [role]. Remove redundancy; merge similar bullets; keep strongest proof.
```

### 3 — CV: gap / career break

```
I was not employed from [dates] because [reason]. Write 1–2 neutral, confident lines for my CV and a short answer for interviews.
```

### 4 — LinkedIn headline

```
Role target: [title]. Skills: [list]. Write 5 headline options ≤220 characters, no buzzword soup.
```

### 5 — LinkedIn About

```
Using my background: [paste CV summary or bullets]. Write a LinkedIn About: hook, proof, what I want next, CTA. 180–220 words.
```

### 6 — Cover letter from job ad

```
Job ad: [paste]. My experience: [paste bullets]. Write a cover letter: 3 short paragraphs, specific to their language, not generic.
```

### 7 — Application answers (word limits)

```
Question: [paste]. Limit: [N] words. My evidence: [paste]. Answer within limit, concrete, no clichés.
```

### 8 — “Tell me about yourself” (60 seconds)

```
Target role: [role]. Background: [paste]. Write a 60-second answer: past → present → future, confident, concise.
```

### 9 — STAR story bank

```
Give me a table of 6 STAR stories from this experience: [paste]. Columns: Situation, Task, Action, Result (with numbers if possible), Best for which interview question.
```

### 10 — Weakness / failure question

```
Write 3 safe answers for “greatest weakness” and 2 for “tell me about a failure” for a [role] interview. Show growth without red flags.
```

### 11 — Why this company

```
Company: [name]. What I like: [notes]. Role: [title]. Write 5 bullets plus a 4-sentence spoken answer.
```

### 12 — Salary expectations

```
Location: []. Role: []. My floor: []. Write how to phrase expectations flexibly without underselling.
```

### 13 — Questions to ask them

```
Role: []. Company stage: []. Give 12 smart questions split: role, team, success metrics, culture, red flags.
```

### 14 — Thank-you email

```
Interviewers: [names/roles]. What we discussed: [notes]. Write a short thank-you email: specific, not groveling.
```

### 15 — Recruiter LinkedIn message

```
I want to reach [type of recruiter] about [role]. Write 4 message variants under 300 characters and 4 longer versions.
```

### 16 — Referral ask

```
Contact: [relationship]. Company: []. Role: []. Write a polite referral request and make it easy to forward.
```

### 17 — Job hopping / short tenures

```
My history: [paste]. Write a calm 30-second explanation and a one-line CV note if needed.
```

### 18 — Career change narrative

```
From [old field] to [new field]. Transferable skills: [list]. Write a story that connects the dots for employers.
```

### 19 — Portfolio / project description

```
Project: [what you built]. Tools: []. Write a portfolio blurb, 3 resume bullets, and 2 interview talking points.
```

### 20 — Interview tomorrow — cram plan

```
Role: []. Company: []. My background: [paste]. Give a 3-hour prep plan: company research checklist, 10 likely questions with outline answers, and 5 stories to memorize.
```

---

## Emergency — interview in 2 hours

```
Role and company: []. Job ad: [paste if any]. My CV: [paste]. Give 10 likely questions with tight bullet answers I can read aloud, plus 5 company-specific lines I can drop in.
```

---

## Power tips (5)

1. Paste the **job ad** first; mirror their language where it’s honest.  
2. One **metric** beats three adjectives — gather numbers before you prompt.  
3. Save **several** headline/About variants; test what gets replies.  
4. For video interviews, ask for **spoken** versions — shorter sentences.  
5. If output sounds generic, add: *“Use my examples only; do not invent employers, degrees, or employers.”*

---

## Remix (add to any prompt)

- `Rewrite more formal for banking/legal tone.`  
- `Rewrite more startup/direct.`  
- `Shorten by 30%.`  
- `I am non-native; keep my facts but smooth the English.`

---

## License

**Personal use only.** Do not resell or redistribute this pack. You are responsible for verifying all facts in AI output. This is not legal or immigration advice.
